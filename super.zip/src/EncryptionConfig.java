import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class EncryptionConfig implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 9175964456025877783L;

	private static final int IV_SIZE = 16;

	public byte[] initializationVector = new byte[IV_SIZE];
	public byte[] signature;
	public String encKeyName;
	public String encKeyPass;
	public String encCryptProvider;
	public String encAlgorithm;
	public String sigKeyName;
	public String signatureAlgorithm;
	public String sigCryptProvider;
	public String keystoreProvider;
	public String keystoreType;
	public String keygenAlgorithm;
	public byte[] encryptedKey;
	public String secretAlgorithm;
	public String secretCryptProvider;
	public String encryptedFile;

	public static EncryptionConfig readFile(String fileName)
			throws Exception {
		FileInputStream fileInputStream = new FileInputStream(fileName);
		ObjectInputStream objInputStream = new ObjectInputStream(fileInputStream);
		EncryptionConfig encParams = (EncryptionConfig) objInputStream.readObject();
		objInputStream.close();
		return encParams;
		
	}

	public void writeFile(String fileName) throws Exception {
		
		FileOutputStream fileOutputStream = new FileOutputStream(fileName);
		ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
		objectOutputStream.writeObject(this);
		objectOutputStream.close();
	}

}
