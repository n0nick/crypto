public class SuperEncryption {

	public static final String STOREFILE = "super_encryption.ks";

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		if (args.length == 3) {
			String operation = args[0];

			if (operation.equals("decrypt")) {
				try {
					SuperDecryptor decryptor = new SuperDecryptor(args[1],
							args[2] + ".config");
					decryptor.decrypt(args[2]);
				} catch (Exception e) {
					System.err.println(e.getMessage());
				}
				return;
			}

			if (operation.equals("encrypt")) {
				try {
					SuperEncryptor encryptor = new SuperEncryptor(args[1]);
					encryptor.encrypt(args[2]);
				} catch (Exception e) {
					System.err.println(e.getMessage());
				}
				return;
			}
		}
		print();
	}

	public static void print() {
		System.err.println("Please supply parameters!");
		System.err.println("SuperEncryption [encrypt/decrypt] [storepass] [file]");
	}

}
