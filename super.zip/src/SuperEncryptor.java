import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.cert.Certificate;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import javax.crypto.Cipher;
import javax.crypto.CipherOutputStream;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

public class SuperEncryptor {

	private Signature signature;

	private Cipher secretCipher;
	private SecretKey secretKey;

	private EncryptionConfig config;

	public SuperEncryptor(String keypass) throws Exception {

		this.config = new EncryptionConfig();
		config.keygenAlgorithm = "AES";
		config.keystoreType = "JCEKS";
		config.signatureAlgorithm = "DSA";
		config.encAlgorithm = "RSA";
		config.encKeyName = "encryptor";
		config.sigKeyName = "decryptor";
		config.secretCryptProvider = "SunJCE";
		config.keystoreProvider = "SunJCE";
		config.secretAlgorithm = "AES/CBC/PKCS5Padding";
		config.encCryptProvider = "SunJCE";
		config.sigCryptProvider = "SUN";
		config.encKeyPass = "SIo6zgbp";
		String decryptorKeyPass = "5uPFWhf5";

		signature = Signature.getInstance(config.signatureAlgorithm);
		KeyGenerator keyGen = KeyGenerator
				.getInstance(config.keygenAlgorithm);
		SecureRandom secRandom = new SecureRandom();
		secRandom.nextBytes(config.initializationVector);
		secretCipher = Cipher.getInstance(config.secretAlgorithm);
		secretKey = keyGen.generateKey();
		Cipher encryptorCipher = Cipher
				.getInstance(config.encAlgorithm);
		KeyStore ks = KeyStore.getInstance(config.keystoreType);
		FileInputStream inputStream = new FileInputStream(
				SuperEncryption.STOREFILE);
		ks.load(inputStream, keypass.toCharArray());
		PrivateKey sigPrivateKey = (PrivateKey) ks.getKey(
				config.sigKeyName, decryptorKeyPass.toCharArray());
		Certificate encryptorCertificate = ks
				.getCertificate(config.encKeyName);
		secretCipher.init(Cipher.ENCRYPT_MODE, secretKey,
				new IvParameterSpec(config.initializationVector));
		encryptorCipher.init(Cipher.ENCRYPT_MODE, encryptorCertificate);
		signature.initSign(sigPrivateKey);
		encryptorCipher.update(secretKey.getEncoded());
		config.encryptedKey = encryptorCipher.doFinal();

	}

	public void encrypt(String filename) throws Exception {
		config.encryptedFile = filename + ".secret";

		FileInputStream fileInput = null;
		FileOutputStream fileOutput = null;
		CipherOutputStream outputStream = null;
		
		try {
			byte[] readBuffer = new byte[8];
			int bytesRead;
			fileInput = new FileInputStream(filename);
			fileOutput = new FileOutputStream(config.encryptedFile);

			outputStream = new CipherOutputStream(fileOutput, secretCipher);

			while ((bytesRead = fileInput.read(readBuffer)) != -1) {
				outputStream.write(readBuffer, 0, bytesRead);
				this.signature.update(readBuffer, 0, bytesRead);
			}

			config.signature = this.signature.sign();

			config.writeFile(filename + ".config");
		} finally {
			outputStream.close();
			fileInput.close();
			fileOutput.flush();
			fileOutput.close();
		}
	}
}
