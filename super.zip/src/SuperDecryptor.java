import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class SuperDecryptor {
	private static final int BUFFER_SIZE = 8;
	private Cipher aesCipher;
	private Signature signature;
	private EncryptionConfig config;

	public SuperDecryptor(String keypass, String configFile) throws Exception {
		this.config = EncryptionConfig.readFile(configFile);
		
		aesCipher = Cipher.getInstance(config.secretAlgorithm,
				config.secretCryptProvider);
		Cipher rsaCipher = Cipher.getInstance(config.encAlgorithm,
				config.encCryptProvider);
		signature = Signature.getInstance(config.signatureAlgorithm,
				config.sigCryptProvider);
		KeyStore keyStore = KeyStore.getInstance(config.keystoreType,
				config.keystoreProvider);
		FileInputStream inputStream = new FileInputStream(
				SuperEncryption.STOREFILE);
		keyStore.load(inputStream, keypass.toCharArray());
		PrivateKey rsaPrivateKey = (PrivateKey) keyStore.getKey(
				config.encKeyName, config.encKeyPass.toCharArray());
		rsaCipher.init(Cipher.DECRYPT_MODE, rsaPrivateKey);
		PublicKey DSAPublicKey = keyStore.getCertificate(
				config.sigKeyName).getPublicKey();
		signature.initVerify(DSAPublicKey);
		rsaCipher.update(config.encryptedKey);
		byte[] aesKeyBytes = rsaCipher.doFinal();
		SecretKey aesKey = new SecretKeySpec(aesKeyBytes,
				config.keygenAlgorithm);
		aesCipher.init(Cipher.DECRYPT_MODE, aesKey, new IvParameterSpec(
				config.initializationVector));
	}

	public void decrypt(String filename) throws Exception {
		String outputFile = filename + ".real";

		FileInputStream signatureFileStream = null;
		FileOutputStream fileOutputStream = null;
		FileInputStream encryptedFileStream = null;
		CipherInputStream inputStream = null;
		byte[] buffer = new byte[8];

		try {
			fileOutputStream = new FileOutputStream(outputFile);
			encryptedFileStream = new FileInputStream(config.encryptedFile);
			inputStream = new CipherInputStream(encryptedFileStream, aesCipher);
			int count;
			while ((count = inputStream.read(buffer)) != -1) {
				fileOutputStream.write(buffer, 0, count);
			}
			signatureFileStream = new FileInputStream(outputFile);
			count = 0;
			byte[] sigBuff = new byte[BUFFER_SIZE];
			while ((count = signatureFileStream.read(sigBuff)) != -1) {
				signature.update(sigBuff, 0, count);
			}
			if (!signature.verify(config.signature)) {
				throw new Exception("Invalid signature");
			}
		} finally {
			signatureFileStream.close();
			inputStream.close();
			fileOutputStream.close();
			encryptedFileStream.close();
		}
	}

}
